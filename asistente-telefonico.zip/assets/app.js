<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>GanaCitas | Agentes IA para llamadas</title>
  <link rel="stylesheet" href="/assets/styles.css" />
  <meta name="description" content="Agencia de agentes IA: recepcionista, citas, WhatsApp y facturas. Planes mensual/anual.">
</head>
<body>
  <div class="container">
    <div class="nav">
      <a class="brand" href="/">
        <span style="width:12px;height:12px;border-radius:999px;background:linear-gradient(90deg,var(--brand),var(--brand2));display:inline-block"></span>
        <span>GanaCitas</span>
      </a>
      <div class="navlinks">
        <a href="/asistente-telefonico/">Asistente telefónico</a>
      </div>
    </div>

    <div class="hero">
      <div class="card p24">
        <h1 class="h1">Convierte llamadas en ventas, citas y atención 24/7</h1>

        <div style="display:flex; flex-direction:column; gap:10px; margin-top:16px; max-width:520px">
          <button class="btn primary" data-open-demo="#demoModal" data-service="asistente-telefonico">Click aquí para probar Asistente Telefónico</button>
          <a class="btn" href="/asistente-telefonico/">Quiero mi asistente telefónico</a>
        </div>

        <div style="margin-top:18px">
          <h3 class="h3">Cómo te ayuda</h3>
          <ul class="ul">
            <li>Atiende llamadas y captura datos automáticamente.</li>
            <li>Agenda citas en tu calendario (Google Calendar u otro) sin intervención humana.</li>
            <li>Reduce llamadas perdidas y acelera conversiones.</li>
          </ul>
        </div>

        <div class="kpis">
          <div class="kpi">✔ Instalación gratuita en 8 a 24h</div>
        </div>
      </div>

      <div class="card p24">
        <h3 class="h3">Listo para negocios locales</h3>
        <p class="muted" style="margin:10px 0 0">Pensado para clínicas, servicios, inmobiliarias y cualquier negocio que no quiere perder llamadas.</p>
      </div>
    </div>

    <div class="footer">
      <div>© 2025 GanaCitas • ganacitas.com</div>
      <div style="display:flex; gap:12px; flex-wrap:wrap">
        <a href="/asistente-telefonico/" class="muted">Asistente telefónico</a>
      </div>
    </div>
  </div>


  <!-- Demo / Config modal -->
  <div id="demoModal" class="modal-backdrop" style="display:none" role="dialog" aria-modal="true" aria-labelledby="demoTitle">
    <div class="modal">
      <div class="modal-header">
        <div>
          <div id="demoTitle" class="modal-title">Configura el asistente telefónico</div>
        </div>
        <button class="icon-btn" type="button" aria-label="Cerrar" data-close="#demoModal">✕</button>
      </div>

      <form data-demo-form>
        <input type="hidden" name="service" value="asistente-telefonico"/>

        <label class="field">
          <span class="label">¿Cuál es el nombre de tu empresa?</span>
          <input name="company" type="text" placeholder="Ej. Clínica Dental Sonríe" autocomplete="organization" required />
        </label>

        <div class="modal-actions">
          <button class="btn" type="button" data-close="#demoModal">Cancelar</button>
          <button class="btn primary" type="submit">Probar Asistente Telefónico</button>
        </div>

      </form>
    </div>
  </div>


  <div id="toast" class="toast"></div>
  <script src="/assets/app.js"></script>
<a class="whatsapp-float"
   href="https://wa.me/34632461050?text=tengo%20una%20duda%20sobre"
   target="_blank"
   aria-label="WhatsApp">
  <img src="/assets/whatsapp.svg" alt="WhatsApp">
</a>
<script>
  window.VAPI_WEB = {
    publicKey: "acef9582-0544-4170-82cc-62e0020fb6df",
    assistantId: "1caed6c8-6768-45d2-989c-2f58d70cc642"
  };
</script>
<script>
  window.vapiInstance = null;

  (function (d, t) {
    var g = document.createElement(t),
      s = d.getElementsByTagName(t)[0];
    g.src = "https://cdn.jsdelivr.net/npm/@vapi-ai/web@latest/dist/index.js";
    g.onload = function () {
      window.vapiInstance = new window.Vapi(window.VAPI_WEB.publicKey);
      console.log("[Vapi] loaded");

      // Helpful debug listeners
      try {
        window.vapiInstance.on("call-end", function () {
          console.log("[Vapi] call ended");
        });
        window.vapiInstance.on("error", function (e) {
          console.error("[Vapi] error", e);
        });
      } catch (e) {
        console.warn("[Vapi] event listeners not supported in this build", e);
      }
    };
    g.onerror = function () {
      console.error("[Vapi] failed to load");
    };
    s.parentNode.insertBefore(g, s);
  })(document, "script");
</script>

</body>
</html>
